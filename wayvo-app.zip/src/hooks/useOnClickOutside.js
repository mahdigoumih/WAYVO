// ============================================
// USE ON CLICK OUTSIDE HOOK
// ============================================

import { useEffect } from "react";

/**
 * Detects clicks outside a referenced element
 * @param {React.RefObject} ref - Reference to element
 * @param {Function} handler - Callback when click outside detected
 */
export function useOnClickOutside(ref, handler) {
  useEffect(() => {
    const listener = (event) => {
      // Do nothing if clicking ref's element or descendent elements
      if (!ref.current || ref.current.contains(event.target)) {
        return;
      }
      handler(event);
    };

    document.addEventListener("mousedown", listener);
    document.addEventListener("touchstart", listener);

    return () => {
      document.removeEventListener("mousedown", listener);
      document.removeEventListener("touchstart", listener);
    };
  }, [ref, handler]);
}

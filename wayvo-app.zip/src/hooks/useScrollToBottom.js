// ============================================
// USE SCROLL TO BOTTOM HOOK
// Auto-scrolls to bottom when dependencies change
// ============================================

import { useEffect, useRef } from "react";

export function useScrollToBottom(dependencies = []) {
  const ref = useRef(null);

  useEffect(() => {
    if (ref.current) {
      ref.current.scrollIntoView({ behavior: "smooth" });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, dependencies);

  return ref;
}

// ============================================
// USE LOCAL STORAGE HOOK
// Replaces the non-existent window.storage API
// ============================================

import { useState, useEffect, useCallback } from "react";

/**
 * Custom hook for persisting state to localStorage
 * @param {string} key - localStorage key
 * @param {*} initialValue - Default value if nothing in storage
 * @returns {[any, Function]} [value, setValue]
 */
export function useLocalStorage(key, initialValue) {
  // Get initial value from localStorage or use default
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.warn(`Error reading localStorage key "${key}":`, error);
      return initialValue;
    }
  });

  // Return a wrapped version of useState's setter that persists to localStorage
  const setValue = useCallback(
    (value) => {
      try {
        // Allow value to be a function so we have same API as useState
        const valueToStore = value instanceof Function ? value(storedValue) : value;
        setStoredValue(valueToStore);
        window.localStorage.setItem(key, JSON.stringify(valueToStore));
      } catch (error) {
        console.warn(`Error setting localStorage key "${key}":`, error);
      }
    },
    [key, storedValue]
  );

  // Listen for changes from other tabs/windows
  useEffect(() => {
    const handleStorageChange = (event) => {
      if (event.key === key && event.newValue) {
        try {
          setStoredValue(JSON.parse(event.newValue));
        } catch (error) {
          console.warn(`Error parsing localStorage change for "${key}":`, error);
        }
      }
    };

    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, [key]);

  return [storedValue, setValue];
}

/**
 * Hook for wishlist with localStorage persistence
 */
export function useWishlistStorage() {
  const [wished, setWished] = useLocalStorage("wv3_wl", []);

  const toggleWish = useCallback(
    (id) => {
      setWished((prev) => {
        const set = new Set(prev);
        if (set.has(id)) {
          set.delete(id);
        } else {
          set.add(id);
        }
        return Array.from(set);
      });
    },
    [setWished]
  );

  const isWished = useCallback(
    (id) => wished.includes(id),
    [wished]
  );

  const clearWishlist = useCallback(() => {
    setWished([]);
  }, [setWished]);

  return {
    wished: new Set(wished),
    wishedArray: wished,
    toggleWish,
    isWished,
    clearWishlist,
    count: wished.length,
  };
}

/**
 * Hook for user profile with localStorage persistence
 */
export function useUserStorage() {
  const [user, setUser] = useLocalStorage("wv3_user", {
    name: "",
    nat: "",
    interests: [],
    city: "Marrakech",
    budget: "",
    trips: 0,
    points: 0,
  });

  const updateUser = useCallback(
    (updates) => {
      setUser((prev) => ({ ...prev, ...updates }));
    },
    [setUser]
  );

  const addPoints = useCallback(
    (points) => {
      setUser((prev) => ({
        ...prev,
        points: prev.points + points,
      }));
    },
    [setUser]
  );

  const resetUser = useCallback(() => {
    setUser({
      name: "",
      nat: "",
      interests: [],
      city: "Marrakech",
      budget: "",
      trips: 0,
      points: 0,
    });
  }, [setUser]);

  return {
    user,
    updateUser,
    addPoints,
    resetUser,
  };
}
